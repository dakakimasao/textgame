package com.mycompany.mytextgame;

public class SaveManager {
}
